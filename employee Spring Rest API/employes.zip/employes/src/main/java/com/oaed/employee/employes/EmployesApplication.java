package com.oaed.employee.employes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployesApplication.class, args);
	}

}
